# TGClient (SwiftUI + TDLibKit)

1. На Mac: `brew install xcodegen`
2. В этой папке: `xcodegen` -> появится TGClient.xcodeproj
3. Откройте в Xcode, дождитесь загрузки пакета TDLibKit (~300 МБ), выберите свою команду подписи, Run.

Ключи API: Sources/TG.swift (enum Config).
Если Xcode ругается на аргументы TDLibKit-методов (setTdlibParameters, sendMessage и т.п.) —
в вашей версии пакета набор параметров может отличаться, подправьте по подсказкам автодополнения.

## IPA через GitHub Actions
Workflow: .github/workflows/build-ipa.yml. Запускается при push в main или вручную (Actions -> Build IPA -> Run workflow).
Готовый TGClient.ipa скачивается из Artifacts. Установка: TrollStore.
