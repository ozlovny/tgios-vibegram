import SwiftUI
import CoreImage.CIFilterBuiltins

@main
struct TGApp: App {
    @StateObject private var tg = TG()
    var body: some Scene {
        WindowGroup {
            Group {
                switch tg.step {
                case .loading:
                    VStack(spacing: 12) {
                        ProgressView()
                        if let e = tg.error { Text(e).font(.footnote).foregroundColor(.red).multilineTextAlignment(.center) }
                        if !tg.connectionText.isEmpty { Text(tg.connectionText).font(.footnote).foregroundColor(.secondary) }
                    }.padding()
                case .ready: MainTabs()
                default: AuthView()
                }
            }
            .environmentObject(tg).tint(Theme.accent)
        }
    }
}


// NavigationStack есть только в iOS 16+, поэтому для iOS 15 используем NavigationView
struct Nav<C: View>: View {
    let content: () -> C
    init(@ViewBuilder _ content: @escaping () -> C) { self.content = content }
    var body: some View { NavigationView { content() }.navigationViewStyle(.stack) }
}

// MARK: - Вход
struct AuthView: View {
    @EnvironmentObject var tg: TG
    @State private var phone = ""
    @State private var code = ""
    @State private var pass = ""

    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            Image(systemName: "paperplane.circle.fill").resizable().frame(width: 110, height: 110).foregroundColor(Theme.accent)
            Text(title).font(.title.bold())
            Text(hint).font(.subheadline).foregroundColor(.secondary).multilineTextAlignment(.center)
            content
            if let e = tg.error { Text(e).font(.footnote).foregroundColor(.red).multilineTextAlignment(.center) }
            if !tg.connectionText.isEmpty { Text(tg.connectionText).font(.footnote).foregroundColor(.secondary) }
            Spacer()
        }
        .padding(28)
    }

    private var title: String {
        switch tg.step {
        case .code: return "Введите код"
        case .password: return "Пароль"
        case .qr: return "Вход по QR"
        default: return "Ваш номер"
        }
    }
    private var hint: String {
        switch tg.step {
        case .code: return "Код придёт в Telegram на другом вашем устройстве или по SMS"
        case .password: return "Включена двухфакторная защита"
        case .qr: return "Telegram на телефоне → Настройки → Устройства → Подключить устройство"
        default: return "Введите номер телефона в международном формате"
        }
    }

    @ViewBuilder private var content: some View {
        switch tg.step {
        case .code:
            field("Код", $code, .numberPad)
            big("Далее") { tg.sendCode(code) }
            Button("Изменить номер") { tg.backToPhone() }
        case .password:
            field("Пароль", $pass, .default, secure: true)
            big("Далее") { tg.sendPassword(pass) }
            Button("Начать заново") { tg.backToPhone() }
        case .qr(let link):
            QRView(text: link).frame(width: 220, height: 220)
            Button("Войти по номеру телефона") { tg.backToPhone() }
        default:
            field("+375 29 1234567", $phone, .phonePad)
            big("Далее") { tg.sendPhone(phone) }
            Button("Войти по QR-коду") { tg.requestQr() }
        }
    }

    private func field(_ ph: String, _ t: Binding<String>, _ kb: UIKeyboardType, secure: Bool = false) -> some View {
        Group { if secure { SecureField(ph, text: t) } else { TextField(ph, text: t).keyboardType(kb) } }
            .multilineTextAlignment(.center).padding(14)
            .background(Color(.secondarySystemBackground)).cornerRadius(12)
    }
    private func big(_ t: String, _ a: @escaping () -> Void) -> some View {
        Button(action: {
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
            a()
        }) { Text(t).font(.headline).frame(maxWidth: .infinity).padding(14)
            .background(Theme.accent).foregroundColor(.white).cornerRadius(12) }
    }
}

func shortDate(_ ts: Int) -> String {
    if ts == 0 { return "" }
    let d = Date(timeIntervalSince1970: TimeInterval(ts))
    let f = DateFormatter()
    let cal = Calendar.current
    if cal.isDateInToday(d) { f.dateFormat = "HH:mm" }
    else if cal.isDate(d, equalTo: Date(), toGranularity: .year) { f.dateFormat = "d MMM" }
    else { f.dateFormat = "dd.MM.yy" }
    return f.string(from: d)
}

struct QRView: View {
    let text: String
    var body: some View {
        let f = CIFilter.qrCodeGenerator(); f.message = Data(text.utf8)
        let img = f.outputImage.map { $0.transformed(by: .init(scaleX: 8, y: 8)) }
        return Group {
            if let img, let cg = CIContext().createCGImage(img, from: img.extent) {
                Image(uiImage: UIImage(cgImage: cg)).interpolation(.none).resizable()
            }
        }.padding(8).background(Color.white).cornerRadius(12)
    }
}

// MARK: - Вкладки
struct MainTabs: View {
    @EnvironmentObject var tg: TG
    @State private var tab = 2
    var body: some View {
        TabView(selection: $tab) {
            Placeholder(title: "Контакты").tabItem { Label("Контакты", systemImage: "person.crop.circle") }.tag(0)
            Placeholder(title: "Звонки").tabItem { Label("Звонки", systemImage: "phone") }.tag(1)
            ChatList().tabItem { Label("Чаты", systemImage: "bubble.left.and.bubble.right") }
                .badge(tg.chats.reduce(0) { $0 + $1.unread }).tag(2)
            SettingsView().tabItem { Label("Настройки", systemImage: "gearshape") }.tag(3)
        }
    }
}

struct Placeholder: View {
    let title: String
    var body: some View { Nav { Text("Скоро").foregroundColor(.secondary).navigationTitle(title) } }
}

struct SettingsView: View {
    @EnvironmentObject var tg: TG
    var body: some View {
        Nav {
            List {
                HStack(spacing: 14) { Avatar(id: 1, title: tg.meName, size: 64)
                    Text(tg.meName).font(.title3.weight(.semibold)) }.padding(.vertical, 6)
                Button("Выйти", role: .destructive) { tg.logOut() }
            }.navigationTitle("Настройки")
        }
    }
}

// MARK: - Список чатов
struct ChatList: View {
    @EnvironmentObject var tg: TG
    @State private var q = ""
    var body: some View {
        Nav {
            List(tg.chats.filter { q.isEmpty || $0.title.localizedCaseInsensitiveContains(q) }) { c in
                NavigationLink { ChatView(chat: c) } label: { Row(c: c) }
            }
            .listStyle(.plain).navigationTitle("Чаты").searchable(text: $q, prompt: "Поиск")
        }
    }
    struct Row: View {
        let c: ChatItem
        var body: some View {
            HStack(spacing: 12) {
                Avatar(id: c.id, title: c.title, size: 54)
                VStack(alignment: .leading, spacing: 3) {
                    Text(c.title).font(.system(size: 16, weight: .semibold)).lineLimit(1)
                    Text(c.preview).font(.system(size: 15)).foregroundColor(.secondary).lineLimit(2)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 6) {
                    Text(shortDate(c.date)).font(.system(size: 13)).foregroundColor(.secondary)
                    if c.unread > 0 {
                        Text("\(c.unread)").font(.system(size: 13, weight: .medium)).foregroundColor(.white)
                            .padding(.horizontal, 7).frame(minWidth: 22, minHeight: 22)
                            .background(Theme.accent).clipShape(Capsule())
                    }
                }
            }.padding(.vertical, 4)
        }
    }
}

// MARK: - Чат
struct ChatView: View {
    @EnvironmentObject var tg: TG
    let chat: ChatItem
    @State private var msgs: [Msg] = []
    @State private var text = ""

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { sp in
                ScrollView {
                    LazyVStack(spacing: 4) { ForEach(msgs) { Bubble(m: $0).id($0.id) } }.padding(10)
                }
                .onChange(of: msgs.count) { _ in if let l = msgs.last { sp.scrollTo(l.id, anchor: .bottom) } }
            }
            HStack(spacing: 8) {
                TextField("Сообщение", text: $text).padding(.horizontal, 14).padding(.vertical, 9)
                    .background(Capsule().stroke(Color.gray.opacity(0.4)))
                Button { send() } label: {
                    Image(systemName: "arrow.up.circle.fill").resizable().frame(width: 34, height: 34)
                }.disabled(text.trimmingCharacters(in: .whitespaces).isEmpty)
            }.padding(8).background(.bar)
        }
        .background(Theme.wallpaper)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { ToolbarItem(placement: .principal) { Text(chat.title).font(.headline) } }
        .task { msgs = await tg.history(chat.id) }
        .onReceive(tg.$incoming) { (new: Msg?) in
            if let m = new, m.chatId == chat.id, !msgs.contains(where: { $0.id == m.id }) { msgs.append(m) }
        }
    }

    private func send() {
        let t = text.trimmingCharacters(in: .whitespaces); text = ""
        Task { await tg.send(chat.id, t) }
    }
}

struct Bubble: View {
    let m: Msg
    var body: some View {
        HStack {
            if m.out { Spacer(minLength: 60) }
            VStack(alignment: .trailing, spacing: 2) {
                Text(m.text).foregroundColor(m.out ? .white : .primary)
                Text(Date(timeIntervalSince1970: TimeInterval(m.date)), style: .time)
                    .font(.system(size: 11)).foregroundColor(m.out ? .white.opacity(0.75) : .secondary)
            }
            .padding(.horizontal, 12).padding(.vertical, 7)
            .background(m.out ? Theme.accent : Theme.incoming)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            if !m.out { Spacer(minLength: 60) }
        }
    }
}
