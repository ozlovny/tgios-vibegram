import Foundation
import TDLibKit

enum Config {
    static let apiId = 34191552
    static let apiHash = "c46295b3a75f76a5990e9aa0814deb5f"
}

enum AuthStep: Equatable { case loading, phone, code, password, qr(String), ready }

struct ChatItem: Identifiable, Hashable {
    let id: Int64
    var title: String
    var preview = ""
    var date = 0
    var unread = 0
}

struct Msg: Identifiable, Hashable {
    let id: Int64
    let chatId: Int64
    let text: String
    let out: Bool
    let date: Int
}

/// Вся работа с Telegram через TDLibKit. UI о TDLib ничего не знает.
@MainActor
final class TG: ObservableObject {
    @Published var step: AuthStep = .loading
    @Published var error: String?
    @Published var chats: [ChatItem] = []
    @Published var meName = ""
    @Published var incoming: Msg?

    private var byId: [Int64: ChatItem] = [:]
    private let manager = TDLibClientManager()
    private var client: TDLibClient!

    init() {
        client = manager.createClient(updateHandler: { [weak self] data, client in
            guard let update = try? client.decoder.decode(Update.self, from: data) else { return }
            Task { @MainActor in self?.handle(update) }
        })
    }

    // MARK: - Updates
    private func handle(_ update: Update) {
        switch update {
        case .updateAuthorizationState(let u):
            Task { await onAuth(u.authorizationState) }
        case .updateNewChat(let u):
            var c = ChatItem(id: u.chat.id, title: u.chat.title)
            c.unread = Int(u.chat.unreadCount)
            if let m = u.chat.lastMessage { c.preview = Self.text(m.content); c.date = m.date }
            byId[c.id] = c; resort()
        case .updateChatLastMessage(let u):
            if var c = byId[u.chatId] {
                c.preview = u.lastMessage.map { Self.text($0.content) } ?? ""
                c.date = u.lastMessage?.date ?? c.date
                byId[c.id] = c; resort()
            }
        case .updateChatReadInbox(let u):
            byId[u.chatId]?.unread = Int(u.unreadCount); resort()
        case .updateNewMessage(let u):
            incoming = Self.map(u.message)
        default: break
        }
    }

    private func resort() { chats = byId.values.sorted { $0.date > $1.date } }

    static func text(_ c: MessageContent) -> String {
        if case .messageText(let t) = c { return t.text.text }
        return "[вложение]"
    }
    static func map(_ m: Message) -> Msg {
        Msg(id: m.id, chatId: m.chatId, text: text(m.content), out: m.isOutgoing, date: m.date)
    }

    // MARK: - Авторизация (https://core.telegram.org/tdlib/docs/classtd_1_1td__api_1_1_authorization_state.html)
    private func onAuth(_ s: AuthorizationState) async {
        do {
            switch s {
            case .authorizationStateWaitTdlibParameters:
                let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
                    .appendingPathComponent("tdlib").path
                try await client.setTdlibParameters(
                    apiHash: Config.apiHash, apiId: Config.apiId, applicationVersion: "1.0",
                    databaseDirectory: dir, databaseEncryptionKey: Data(), deviceModel: "iPhone",
                    filesDirectory: "", systemLanguageCode: "ru", systemVersion: "",
                    useChatInfoDatabase: true, useFileDatabase: true, useMessageDatabase: true,
                    useSecretChats: false, useTestDc: false)
            case .authorizationStateWaitPhoneNumber: step = .phone
            case .authorizationStateWaitOtherDeviceConfirmation(let q): step = .qr(q.link)
            case .authorizationStateWaitCode: step = .code
            case .authorizationStateWaitPassword: step = .password
            case .authorizationStateReady:
                step = .ready
                let me = try await client.getMe()
                meName = [me.firstName, me.lastName].filter { !$0.isEmpty }.joined(separator: " ")
                try await client.loadChats(chatList: .chatListMain, limit: 50)
            default: break
            }
        } catch { self.error = "\(error)" }
    }

    func sendPhone(_ p: String) { run { try await self.client.setAuthenticationPhoneNumber(phoneNumber: p, settings: nil) } }
    func sendCode(_ c: String) { run { try await self.client.checkAuthenticationCode(code: c) } }
    func sendPassword(_ p: String) { run { try await self.client.checkAuthenticationPassword(password: p) } }
    func requestQr() { run { try await self.client.requestQrCodeAuthentication(otherUserIds: []) } }
    func logOut() { run { try await self.client.logOut() } }

    private func run<T>(_ f: @escaping () async throws -> T) {
        error = nil
        Task { do { _ = try await f() } catch { self.error = "\(error)" } }
    }

    // MARK: - Сообщения
    func history(_ chatId: Int64) async -> [Msg] {
        let r = try? await client.getChatHistory(chatId: chatId, fromMessageId: 0, limit: 40, offset: 0, onlyLocal: false)
        return (r?.messages ?? []).reversed().map(Self.map)
    }

    func send(_ chatId: Int64, _ text: String) async {
        let content = InputMessageContent.inputMessageText(
            InputMessageText(clearDraft: true, linkPreviewOptions: nil,
                             text: FormattedText(entities: [], text: text)))
        do {
            _ = try await client.sendMessage(chatId: chatId, inputMessageContent: content,
                                             options: nil, replyMarkup: nil, replyTo: nil, topicId: nil)
        } catch { self.error = "\(error)" }
    }
}
