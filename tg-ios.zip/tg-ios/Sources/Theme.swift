import SwiftUI

// Палитра и размеры как в Telegram для iOS
enum Theme {
    static let accent = Color(red: 0.0, green: 0.48, blue: 1.0)
    static let wallpaper = Color(UIColor { $0.userInterfaceStyle == .dark
        ? UIColor(red: 0.05, green: 0.08, blue: 0.11, alpha: 1)
        : UIColor(red: 0.85, green: 0.91, blue: 0.93, alpha: 1) })
    static let incoming = Color(UIColor { $0.userInterfaceStyle == .dark
        ? UIColor(red: 0.12, green: 0.16, blue: 0.20, alpha: 1) : .white })
    static let avatarColors: [[Color]] = [
        [.init(red: 1, green: 0.52, blue: 0.45), .init(red: 0.9, green: 0.27, blue: 0.3)],
        [.init(red: 1, green: 0.8, blue: 0.4), .init(red: 0.95, green: 0.55, blue: 0.1)],
        [.init(red: 0.75, green: 0.55, blue: 1), .init(red: 0.5, green: 0.3, blue: 0.9)],
        [.init(red: 0.6, green: 0.9, blue: 0.5), .init(red: 0.2, green: 0.7, blue: 0.3)],
        [.init(red: 0.5, green: 0.9, blue: 0.95), .init(red: 0.1, green: 0.65, blue: 0.8)],
        [.init(red: 0.5, green: 0.7, blue: 1), .init(red: 0.2, green: 0.45, blue: 0.95)],
        [.init(red: 1, green: 0.6, blue: 0.8), .init(red: 0.9, green: 0.3, blue: 0.6)]
    ]
}

struct Avatar: View {
    let id: Int64, title: String, size: CGFloat
    var body: some View {
        let c = Theme.avatarColors[Int(abs(id) % 7)]
        Circle()
            .fill(LinearGradient(colors: c, startPoint: .top, endPoint: .bottom))
            .frame(width: size, height: size)
            .overlay(Text(String(title.prefix(1)).uppercased())
                .font(.system(size: size * 0.42, weight: .medium)).foregroundColor(.white))
    }
}
